import random
import pandas as pd
from datetime import datetime, timedelta

# Function to generate random dates
def random_date(start_date, end_date):
    delta = end_date - start_date
    random_days = random.randint(0, delta.days)
    return start_date + timedelta(days=random_days)

# Define the ranges and options for each feature
features = {
    "Name": ["John Doe", "Jane Smith", "David Miller", "Emily Brown", "Michael Wang", "Alice Johnson", "Robert Lee", "Emma Davis", "Daniel Martinez", "Sarah Wilson"],
    "Institution": ["ABC University", "XYZ College", "PQR Institute", "LMN School", "RST College", "UVW Academy"],
    "Date of Birth": (datetime(1960, 1, 1), datetime(2005, 12, 31)),
    "Educational Qualification": ["Undergraduate", "Postgraduate", "PHD"],
    "Marital Status": ["Single", "Married", "A single parent"],
    "Monthly Income Range": ["Less than 50K", "50K - 1L", "More than 1L"],
    "Number of Children": (0, 5),
    "Number of Family Members": (1, 10),
    "Number of Working Professionals": (0, 10),
    "Taking care of any elderly or sick family member?": ["Yes", "No"],
    "Household and Job Management": ["Easy", "Difficult", "Neither"],
    "Working Hours (Per day)": (1, 10),
    "Working days per week": (1, 6),
    "Interest in Job": ["A great deal", "Moderately", "Not at all"],
    "Working Condition Satisfaction": ["Extremely Satisfied", "Satisfied", "Neither Satisfied nor Dissatisfied", "Dissatisfied", "Most Dissatisfied"],
    "Salary Satisfaction": ["Extremely Satisfied", "Satisfied", "Neither Satisfied nor Dissatisfied", "Dissatisfied", "Most Dissatisfied"],
    "Working Overtime?": ["Yes", "No"],
    "Colleagues or friends to help with work?": ["Yes", "No"],
    "Academic/Work pressure": ["Agree", "Disagree", "Neutral"],
    "Stress because of students": ["Always", "Often", "Occasionally", "Rarely", "Never"],
    "Heavy workload": ["Significantly", "Moderately", "Slightly", "Not At All"],
    "Difficulty in managing time?": ["Yes", "No"],
    "Difficulty in sleeping": ["Always", "Sometimes", "Never", "Usually"],
    "Frequent headaches": ["Yes", "No"],
    "Tired during working hours": ["Always", "Sometimes", "Never", "Usually"],
    "Body pain or neck pain": ["Body Pain", "Neck Pain", "Both", "Neither"],
    "Need to take a break from work?": ["Yes", "No"],
    "Measures taken to overcome stress": ["Exercise", "Meditation", "Socializing", "Yoga", "Music", "Hobbies", "Other"],
    "Heart rate": ["Less than 60 bpm", "60 to 70 bpm", "70 to 80 bpm", "80 to 90 bpm", "More than 90 bpm"],
    "Breathing rate": (12, 20),
    "Skin temperature (°F)": (90, 100),
    "Oxygen saturation level (%)": (92, 100),
    "Resting heart rate": (60, 100),
    "Stress Level": ["Low", "Moderate", "High"]
}

# Generate synthetic data
num_data_points = 100
data = {}
for feature, values in features.items():
    if isinstance(values, list):
        data[feature] = [random.choice(values) for _ in range(num_data_points)]
    elif isinstance(values, tuple):
        if feature == "Date of Birth":
            start_date, end_date = values
            data[feature] = [random_date(start_date, end_date).strftime("%d-%m-%Y") for _ in range(num_data_points)]
        else:
            data[feature] = [random.randint(values[0], values[1]) for _ in range(num_data_points)]

# Convert data to DataFrame
df = pd.DataFrame(data)

# Save DataFrame to CSV file
df.to_csv("synthetic_data.csv", index=False)

# Display the DataFrame
print(df)
