from flask import Flask, render_template, request
from sklearn.preprocessing import StandardScaler, LabelEncoder
from keras.models import Sequential
from keras.layers import Dense, Dropout
import numpy as np
import pandas as pd

# Load data from CSV file (replace path with your actual file)
data = pd.read_csv("data.csv")

# Preprocessing function
def preprocess_data(data):
    # One-hot encode categorical variables
    #categorical_cols = data.select_dtypes(include=['object']).columns
    #categorical_data_encoded = pd.get_dummies(X, columns=categorical_cols, drop_first=True)
    # Define top 10 encoded features
    top_10_encoded_features = ["Resting heart rate", "Working Hours (Per day)", "Skin temperature (°F)", 
                               "Oxygen saturation level (%)", "Number of Family Members", "Breathing rate", 
                               "Number of Working Professionals", "Number of Children", "Working days per week", 
                               ]

    # Select top 10 encoded features
    data_selected = data[top_10_encoded_features]

    # Scale selected features
    scaler = StandardScaler()
    data_scaled = scaler.fit_transform(data_selected)

    return data_scaled

# Preprocess data
data_preprocessed = preprocess_data(data)

# Define X and y
X = data_preprocessed
y = data["Stress Level"]

# Fit and transform LabelEncoder for target variable
le = LabelEncoder()
y_encoded = le.fit_transform(y)

def federated_averaging(local_weights):
    # Separate weights and biases arrays
    weights_list = [weights[::2] for weights in local_weights]
    biases_list = [weights[1::2] for weights in local_weights]

    averaged_weights = []
    for layer_weights in zip(*weights_list):
        layer_mean = np.mean(layer_weights, axis=0)
        averaged_weights.append(layer_mean)

    averaged_biases = []
    for layer_biases in zip(*biases_list):
        layer_mean = np.mean(layer_biases, axis=0)
        averaged_biases.append(layer_mean)

    # Combine averaged weights and biases
    averaged_weights_and_biases = [avg_weights for pair in zip(averaged_weights, averaged_biases) for avg_weights in pair]

    return averaged_weights_and_biases




# Build ANN model
model = Sequential([
    Dense(128, activation="relu", input_shape=(X.shape[1],)),
    Dropout(0.2),
    Dense(64, activation="relu"),
    Dense(3, activation="softmax")  # softmax for multi-class classification (low/medium/high stress)
])
model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])

# Data Partitioning (replace with desired number of partitions)
data_partitions = np.array_split(data_preprocessed, 4)
target_partitions = np.array_split(y_encoded, 4)

# Number of federated learning rounds
num_rounds = 3

# Define local model architecture
local_model_architecture = [
    Dense(128, activation="relu", input_shape=(X.shape[1],)),
    Dropout(0.2),
    Dense(64, activation="relu"),
    Dense(3, activation="softmax")
]

# Federated Learning Simulation
for round in range(num_rounds):
    # Train local models on data partitions
    local_weights = []
    for partition, y_partition in zip(data_partitions, target_partitions):
        # Create local model using the defined architecture
        local_model = Sequential(local_model_architecture)
        local_model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])

        local_model.fit(partition, y_partition, epochs=2, batch_size=32)
        local_weights.append(local_model.get_weights())

        # Print the shape of each layer's weights
        #for layer_weights in local_model.get_weights():
            #print(layer_weights.shape)

    # Federated averaging
    averaged_weights = federated_averaging(local_weights)

    # Update central model with averaged weights
    model.set_weights(averaged_weights)


# Define Flask app
app = Flask(__name__)

# Define routes
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    # Get user input from the form
    user_data = request.form.to_dict()

    # Convert user data to a Pandas DataFrame (single row)
    user_df = pd.DataFrame([user_data])

    # Scale selected features
    scaler = StandardScaler()
    user_preprocessed = scaler.fit_transform(user_df)

    # Predict stress level using the trained model
    predicted_stress = model.predict(user_preprocessed)[0]

    # Get the index of the maximum probability class
    predicted_stress_category = le.inverse_transform([np.argmax(predicted_stress)])[0]

    # Prepare recommendations based on stress category (dummy recommendations)
    recommendations = {
        "Low": "You seem to be managing stress well. Keep up the good work!",
        "Moderate": "Consider incorporating some relaxation techniques like deep breathing or meditation into your routine.",
        "High": "Your stress level seems high. Explore stress management strategies like exercise, yoga, or seeking professional help."
    }

    return render_template("result.html", stress_category=predicted_stress_category, recommendation=recommendations[predicted_stress_category])

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)
